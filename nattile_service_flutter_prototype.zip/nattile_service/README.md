# നാട്ടിലെ Service — Flutter Prototype

## Run
1. Install Flutter and Android Studio.
2. Open this folder in Android Studio or VS Code.
3. Run `flutter pub get`.
4. Connect an Android phone/emulator.
5. Run `flutter run`.

This is an MVP UI prototype. Worker data is currently sample/local data; registration does not yet save to an online database.
